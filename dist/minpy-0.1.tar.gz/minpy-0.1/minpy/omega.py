class Omega:
    def __init__(self):
        pass

    def method(self):
        print("Hello Google Colab!")
