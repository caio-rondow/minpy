# minpy
Python library to use Multistage Interconnection Network (MIN) structures
